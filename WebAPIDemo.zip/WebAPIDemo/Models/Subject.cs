﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIDemo.Models
{
    public class Subject
    {
        public int Sid { get; set; }
        public string SName { get; set; } = string.Empty;
        public string SDesc { get; set; } = string.Empty;
        
    }
   
}
