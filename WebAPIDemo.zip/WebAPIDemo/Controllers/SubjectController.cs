﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIDemo.Models;

namespace WebAPIDemo.Controllers
{
    [Route("api/Student/{sid}/[controller]/")]
    [ApiController]
    public class SubjectController : ControllerBase
    {
        //injecting logger to log the information of operations
        private readonly ILogger<SubjectController> _logger;
        public SubjectController(ILogger<SubjectController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public ActionResult<Subject> GetSubjects(int sid)
        {
            var data = StudentSubjectCollection.Current.StudentsList.FirstOrDefault(f=>f.Id==sid);
            if (data == null){
                return NotFound();
            }
            var data1 = data.Subjects;
            if (data1 == null)
            {
                _logger.LogInformation($"the Subject with ID: {sid} you are looking for is not available!");
                return NotFound();
            }
            return Ok(data1);
        }
        [HttpGet("{id}",Name ="GetSubject")]
        public IActionResult GetSubjectbyId(int sid,int id)
        {
            var data = StudentSubjectCollection.Current.StudentsList.FirstOrDefault(f => f.Id == sid);
            if (data == null)
            {
                return NotFound();
            }
            var data1 = data.Subjects.FirstOrDefault(f=>f.Sid==id);
            if (data1 == null)
            {

                return NotFound();
            }
            return Ok(data1);
        }

        [HttpPost]
        public ActionResult<Subject> CreateSub(int sid, AddSubject _subject)
        {
            var stud = StudentSubjectCollection.Current.StudentsList.FirstOrDefault(c => c.Id == sid);

            if (stud == null){
                return NotFound();
            }

            var maxsubid = StudentSubjectCollection.Current.StudentsList.SelectMany(c => c.Subjects).Max(p => p.Sid);
            Subject tempsub = new Subject()
            {
                Sid = ++maxsubid,
                SName = _subject.Name,
                SDesc = _subject.Desc

            };
           
            stud.Subjects.Add(tempsub);

            return CreatedAtRoute("GetSubject",
                new
                {
                    sid = stud.Id,
                    id = tempsub.Sid
                }, 
                tempsub);
        }

        [HttpPut("{id}")]
        public ActionResult UpdateSubject(int sid,int id,UpdateSubject _updatesub)
        {
            var data = StudentSubjectCollection.Current.StudentsList.FirstOrDefault(f => f.Id == sid);
            if (data == null)
            {
                return NotFound();
            }
            var data1 = data.Subjects.FirstOrDefault(f => f.Sid == id);
            if (data1 == null)
            {

                return NotFound();
            }

            data1.SName = _updatesub.Name;
            data1.SDesc = _updatesub.Desc;

            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteSub(int sid,int id)
        {
            var data = StudentSubjectCollection.Current.StudentsList.FirstOrDefault(f => f.Id == sid);
            if (data == null)
            {
                return NotFound();
            }
            var data1 = data.Subjects.FirstOrDefault(f => f.Sid == id);
            if (data1 == null)
            {
                return NotFound();
            }
            data.Subjects.Remove(data1);
            return NoContent();
        }
    }
}
