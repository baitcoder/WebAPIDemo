﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.StaticFiles;

namespace WebAPIDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileController : ControllerBase
    {
        private readonly FileExtensionContentTypeProvider _fileExtensionContentTypeProvider;
        public FileController(FileExtensionContentTypeProvider fileExtensionContentTypeProvider)
        {
            _fileExtensionContentTypeProvider = fileExtensionContentTypeProvider ??
                throw new System.ArgumentNullException(nameof(fileExtensionContentTypeProvider));
        }
        [HttpGet("{fileid}")]
        public ActionResult GetFile(string fileId)
        {
            //lookup the actual file, depending on file ID
            var filepath = "sampletxtfile.txt";

            if (!System.IO.File.Exists(filepath))
            {
                return NotFound();
            }
            if (!_fileExtensionContentTypeProvider.TryGetContentType(filepath,out var contentType))
            {
                contentType = "application/octet-stream";
            }

            var bytes = System.IO.File.ReadAllBytes(filepath);
            return File(bytes,contentType, Path.GetFileName(filepath));
            
         
        }
        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            //validate the input . put a size limit to avoid large attachments.
            //only accept .pdfs 
            if(file.Length==0 || file.Length>20971520 || file.ContentType != "application/pdf")
            {
                return BadRequest("no file or invalid format file upload");
            }

            //create a file path. dont use file.Filename as attacker can provide a
            //malicious or dont include full paths
            var path = Path.Combine(Directory.GetCurrentDirectory(), $"Uploaded_File_{Guid.NewGuid()}");
            using (var stream = new FileStream(path, FileMode.Create)) 
            {
                await file.CopyToAsync(stream);
            }
            return Ok("File Uploaded Sucess");

        }
    }
}
